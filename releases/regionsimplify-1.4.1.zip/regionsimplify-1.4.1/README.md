See [online documentation](https://github.com/eurostat/EuroGen/blob/master/regionsimplify.md).
